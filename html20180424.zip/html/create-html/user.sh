# !/bin/sh
TIME=`date +%Y年%m月%d日%H时%M分`
file_input=$1
tmp=`echo $1|awk -F "/" '{print $NF}'`
file_output="/var/www/html/html/${tmp}"
td_str=''
function create_html_head(){
     cat /var/www/html/head/user.html
}
function create_table_head(){
  echo -e "<body>"
  echo -e "<div>"
  echo -e "<a><img src=\"/image/logo.png\" width=\"100%;\"></a>"
  echo -e "</div>"
  echo -e "<div id="content">"
  echo -e "<table id="table1">"
  echo -e "<h2 align="left"><a  href="http://yjsc.xtu.edu.cn/index.html" target="_blank">${TIME}</a> &nbsp;&nbsp; <a href="/html/question.html" >作业提交常见问题</a> &nbsp;&nbsp; <a href="http://172.16.40.21">返回主页</a> </font></h2>"
  #echo -e "<h2 align="left"><a  href="http://yjsc.xtu.edu.cn/index.html" target="_blank">${TIME}</a> &nbsp;&nbsp;<a  href="image/Cluster" target="_blank">HPCHPC拓扑图</a> &nbsp;&nbsp; <a href="http://172.16.40.21">返回主页</a> </font></h2>"
  echo -e "<tbody>"
}
function create_td(){
	echo "$1"|grep -E "ID" &> /dev/null
	if [ $? -eq 0 ];then
	   echo $1
	   td_str=`echo "$1"|awk 'BEGIN{FS=" "}{i=1; while(i<=NF){print "<th>"$i"</th>";i++}}'`
	   echo $td_str
	   #break
	else
           echo $1
           td_str=`echo "$1"|awk 'BEGIN{FS=" "}{i=1; while(i<=NF){print "<td>"$i"</td>";i++}}'`
           echo $td_str
	   
	fi
}
function create_tr(){
  create_td "$1"
  echo -e "<tr align=center>
    $td_str
  </tr>" >> $file_output
}
function create_table_end(){
  echo -e "</tbody>"
  echo -e "</table>"
  echo -e "</div>"
}
function create_html_end(){
  echo -e "<div><a><img src=\"/image/bottom.png\" width=\"100%;\"></a></div>"
  echo -e "</body></html>"
}
function create_html(){
  rm -rf $file_output
  touch $file_output
  create_html_head >> $file_output
  create_table_head >> $file_output
  while read line
  do
    echo $line
    create_tr "$line"
  done < $file_input
  create_table_end >> $file_output
  create_html_end >> $file_output
}
create_html
sed -i 's@\(c0[1-7]n[0-1][0-9]\)@<a href=http://172.16.40.21/html/node/\1.html style="font-weight: 500">\1</a>@g' $file_output
