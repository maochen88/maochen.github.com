# !/bin/sh
#sed -i 's@/gpfsHOME/home/st/@     @g' /tmp/txt
#grep "T" /tmp/txt|awk -F "T" 'BEGIN{CONVFMT="%0.1f"}{print $2,"\t",$1*1024"G","\t",100*$1*1024/30/1024"%"}' > /tmp/Cluster.log
#grep "G" /tmp/txt|awk 'BEGIN{CONVFMT="%0.1f"}{print $2,"\t",$1,"\t",100*$1/30/1024"%"}' >> /tmp/Cluster.log
#grep "T" /tmp/txt|awk -F "T" '{print $2,"\t",$1*1024"G"}' > /tmp/Cluster.log
#grep "G" /tmp/txt|awk '{print $2,"\t",$1}'>> /tmp/Cluster.log
#sort -k2 -r -n /tmp/Cluster.log > /tmp/xtuhpc.log
#sed -i '1iUser\t\tUsage\t\tPercent' /tmp/xtuhpc.log
TIME=`date +%Y年%m月%d日%H时%M分`
file_input='/var/www/html/data/job.log'
file_output='/var/www/html/index.html'
TIME1=`date +%Y年%m月%d日%H:%M:%S`
TIME2=`date +%H%M`
#TIME2=0003
td_str=''

function create_html_head(){
     cat /var/www/html/head/head.html
}
 
function create_table_head(){
  echo -e "<body>"
  echo -e "<div>"
  echo -e "<a><img src=\"/image/logo.png\" width=\"100%;\"></a>"
  echo -e "</div>"
  echo -e "<div id="content">"
  echo -e "<table id="table1">"
  echo -e "<h2 align="right"><a  href="http://yjsc.xtu.edu.cn/index.html" target="_blank">${TIME}</a> &nbsp;&nbsp; <a href="http://math.xtu.edu.cn/myphp/math/lab_2016/" target="_blank">实验室简介</a> &nbsp;&nbsp; <a  href="/image/Cluster" >HPC拓扑图</a> &nbsp;&nbsp; <a href="http://172.16.40.21">主页</a></font></h2>"
  #echo -e "<h2 align="right"><a  href="http://yjsc.xtu.edu.cn/index.html" target="_blank">${TIME}</a> &nbsp;&nbsp; <a href="http://math.xtu.edu.cn/myphp/math/lab_2016/" target="_blank">实验室简介</a> &nbsp;&nbsp; <a  href="/image/Cluster" >HPC拓扑图</a></font></h2>"
  #echo -e "<h2 align="right"><font  face="arial" color=#B40431>${TIME}&nbsp;&nbsp;<a  href="image/Cluster" target="_blank">HPCHPC拓扑图</a>  <a href="http://math.xtu.edu.cn/myphp/math/lab_2016/" target="_blank">简介</a> </font></h2>"
  #echo -e "<h2 align="right"><font  face="arial" color=#B40431>更新时间 &#8594; ${TIME}<a href="http://math.xtu.edu.cn/myphp/math/lab_2016/">HPCHPC拓扑图简介</a> </font></h2>"
  echo -e "<tbody>"
}

 
function create_td(){
	echo "$1"|grep -E "30T|RUN|总计" &> /dev/null
	S1=$?
	echo "$1"|grep  "%" &> /dev/null
	S2=$?
	S3=`echo "$1"|awk '{if($2>=1){print $2}}'`
	
	if [ ${S1} -eq 0 ];then
	   echo $1
	   td_str=`echo "$1"|awk 'BEGIN{FS=" "}{i=1; while(i<=NF){print "<th>"$i"</th>";i++}}'`
	   echo $td_str
	   #break
	elif [ ${S2} -eq 0 -a -n "${S3}" ];then
	   echo $1
           td_str=`echo "$1"|awk 'BEGIN{FS=" "}{for(i=1;i<=NF;i++){if(i<=NF-2){print "<td><font color=\"red\"><b>"$i"</b></td>"}else{print "<td>"$i"</td>"}}}'`
           echo $td_str
	else
	   echo $1
           td_str=`echo "$1"|awk 'BEGIN{FS=" "}{i=1; while(i<=NF){print "<td>"$i"</td>";i++}}'`
           echo $td_str
	fi
}
 
function create_tr(){
  create_td "$1"
  echo -e "<tr align=center>
    $td_str
  </tr>" >> $file_output
}
 
function create_table_end(){
  echo -e "</tbody>"
  echo -e "</table>"
  echo -e "</div>"
}
 
function create_html_end(){
  echo -e "<div><a><img src=\"/image/bottom.png\" width=\"100%;\"></a></div>"
  echo -e "</body></html>"
}
 
 
function create_html(){
  rm -rf $file_output
  touch $file_output
 
  create_html_head >> $file_output
  create_table_head >> $file_output
 
  while read line
  do
    echo $line
    create_tr "$line"
  done < $file_input
 
  create_table_end >> $file_output
  create_html_end >> $file_output
}

unalias cp &> /dev/null

#/bin/netstat -atn|awk -F ":" '{print $(NF-1)}'|grep '[1-9]\{1,3\}.*'|sort |uniq -c|sort -k1r|awk '{if($1>100)print $2}'

#判定集群是否可以连接
ping -c 1 -w 1 172.16.40.6 &> /dev/null
[ $? -eq 0 ] || cp -rf /var/www/html/head/bak.html /var/www/html/index.html

#凌晨00:00-02:00不进行数据的更新
if [ "$TIME2" -ge "0001" -a "$TIME2" -lt "0200" ];then
   sed "s/TimeDate/当前时间: ${TIME1}/g" /var/www/html/head/updata.html > /var/www/html/index.html 
   cp -rf /var/www/html/index.html /var/www/html/head/
else
   create_html
   /bin/bash  /var/www/html/create-html/cpu.sh
   /bin/bash  /var/www/html/create-html/gpu.sh
   /bin/bash  /var/www/html/create-html/create-user.sh
   /bin/bash  /var/www/html/create-html/create-node.sh
   cp -rf /var/www/html/index.html /var/www/html/html/
fi
