#!/bin/bash

rm -rf /var/www/html/data/node &> /dev/null
mkdir -p /var/www/html/data/node &> /dev/null
/bin/tar zxf /var/www/html/data/node.tar.gz  -C /var/www/html/data/node/  &> /dev/null
find /var/www/html/data/node/usr -type f -exec mv {} /var/www/html/data/node/  \;

for node in `ls /var/www/html/data/node/*[0-9]`;do
    /bin/bash /var/www/html/create-html/node.sh ${node} &> /dev/null
    NODE=`echo ${node}|awk -F "/" '{print $NF}'`
    sed -i "s@${NODE}<@<a href=http://172.16.40.21/html/node/${NODE}.html style=\"font-weight: 500\">${NODE}</a><@g" \
     /var/www/html/html/CPU
    sed -i "s@${NODE}<@<a href=http://172.16.40.21/html/node/${NODE}.html style=\"font-weight: 500\">${NODE}</a><@g" \
     /var/www/html/html/GPU
done
