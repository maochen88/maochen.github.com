#!/bin/bash

input_file='/var/www/html/data/job.log'
USER_HEAD='/var/www/html/data/user_head'
LOG='/var/www/html/data/user.log'
HTML='/var/www/html/data'

for i in `grep [a-z] ${input_file}|awk '{print $1}'`;do
	cat ${USER_HEAD} > ${HTML}/$i 
	grep "$i\b" ${LOG} >> ${HTML}/$i
	sed -i 's/\(c[0-1][0-9]n[0-1][0-9]\):/\1<\\br>/g' ${HTML}/$i
	sed -i 's/\(gpu0[0-9]\):/\1<\\br>/g' ${HTML}/$i
	/bin/bash /var/www/html/create-html/user.sh ${HTML}/$i
	sed -i "s@$i<@<a href=http://172.16.40.21/html/$i style=\"font-weight: 500\">$i</a><@g" /var/www/html/index.html
done
